import tkinter
from tkinter import *
##Import of Tkinter module

window = Tk()
##Creates the window from the imported Tkinter module
window.geometry("600x400")
##Creates the size of the window
window.title("Test :)")
##Adds a title to the Windows GUI for the window

window.mainloop()
##Loops the window to prevent the window from just "flashing once"